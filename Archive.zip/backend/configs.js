configs={
    db_url_local : "mongodb://localhost:27017",
    db_name : "hystechsales",
}
module.exports=configs;