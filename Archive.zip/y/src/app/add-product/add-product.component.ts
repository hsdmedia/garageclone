import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { DataService } from '../data.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.scss']
})
export class AddProductComponent implements OnInit {

  productFormData = new FormData();
  selectedFile: any;
  logoImgSrc: string;
  selectedLogo: any;
  logoPreview: string
  productForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private dataService:DataService) {
    this.productForm = formBuilder.group({
      name: ['', Validators.required],
      packages: formBuilder.array([this.createPackage()]),
      description: ['', Validators.required],
      logo: ['', Validators.required],
      faqs: formBuilder.array([this.createFaq()]),
    })
  }

  ngOnInit(): void {
  }
  createFaq() {
    return this.formBuilder.group({
      question: [''],
      answer: [''],
    })
  }
  createPackage() {
    return this.formBuilder.group({
      name: [''],
      price: [''],
      details: [''],
    })
  }
  logoSelect(event: any) {
    this.selectedLogo = (event.target as HTMLInputElement).files[0];
    const allowedMimeTypes = ['image/png', 'image/jpeg', 'image/jpg'];
    console.log('Logo: ', this.selectedLogo);
    if (!this.selectedLogo || !allowedMimeTypes.includes(this.selectedLogo.type)) {
      (document.getElementById('logoInput') as HTMLInputElement).value = '';
      return;
    }
    let fileReader = new FileReader();
    fileReader.readAsDataURL(this.selectedLogo);
    fileReader.onload = () => {
      this.logoImgSrc = fileReader.result as string;
    };
    this.productFormData.append('logoFile', this.selectedLogo, this.productForm.value.name + '_logo.' + this.selectedLogo.type.split('/')[1]);
  }
  newFaq() {
    this.faqs.push(this.createFaq());
  }
  newPackage() {
    this.packages.push(this.createPackage());
  }
  fileSelect($event) {
    this.selectedFile = (event.target as HTMLInputElement).files[0];
    this.productFormData.append('attacchmentFile', this.selectedFile, this.productForm.value.name + '_attachment.' + this.selectedFile.type.split('/')[1]);
  }
  get faqs() {
    return this.productForm.get('faqs') as FormArray;
  }
  get packages() {
    return this.productForm.get('packages') as FormArray;
  }
  addFaq() {

  }
  removeFaq(index: number) {
    this.faqs.removeAt(index);
  }
  onFormSubmit() {
    this.productFormData.append('productDetail', JSON.stringify(this.productForm.value));
    this.dataService.addProduct(this.productFormData).subscribe(resp=>{
      console.log('Product add resp: ',resp);
      
    })
    console.log('form value: ', this.productForm.value);
  }
}
