import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-salesperson',
  templateUrl: './add-salesperson.component.html',
  styleUrls: ['./add-salesperson.component.scss']
})
export class AddSalespersonComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
